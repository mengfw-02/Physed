/*class StraightMotion extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
          time: 0
        };
        this.handleChange = this.handleChange.bind(this);
          
        const canvas = document.querySelector('canvas');
        const ctxt = canvas.getContext('2d');
        canvas.width = 500;
        canvas.height = 500; 
         
    
    }
    
    handleChange(event) {
        this.setState({time: event.target.value});
      
        
    }
   
        render() {
            draw();
            ctx.fillRect(40,40, 50, 50);
            return(
                <div>
                    <NoAcceleration />
                    <Slider time={this.time} handleChange={this.handleChange}/>
                </div>
            );
        }
}


class NoAcceleration extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            
        };
    }
   

}

class Slider extends React.Component {
    constructor(props) {
        super(props);
        this.state = {time: this.props.time};
        
    }
  

    render() {
        return(
            <div>
                <input onChange={this.props.handleChange} type="range" min="0" max="5" step="1" value={this.state.time} class="slider" id="accRangeS"></input>
            </div>
        );
    }
} */




//ReactDOM.render(<StraightMotion />, document.getElementById("game_container"));

var canvas = document.getElementById("noACanvas");
var cntxt=canvas.getContext("2d");
var timeRange = document.getElementById("timeRange");
var xPosConstantV = 100;
var xPosConstantA = 100;
var vStart = 5;
var a = 5;
var t = 0;
timeRange.addEventListener("change", redraw);

/*cntxt.beginPath(); 
cntxt.arc(200, 100, 50, 0 * Math.PI, 2.0 * Math.PI);
cntxt.fillStyle = "blue";
cntxt.fill();*/

cntxt.beginPath(); 
cntxt.arc(100, 100, 25, 0 * Math.PI, 2.0 * Math.PI);
cntxt.fillStyle = "blue";
cntxt.fill();

cntxt.beginPath(); 
cntxt.arc(100, 200, 25, 0 * Math.PI, 2.0 * Math.PI);
cntxt.fillStyle = "blue";
cntxt.fill();

function redraw() {
    cntxt.clearRect(0, 0, canvas.width, canvas.height);
    t = this.value - t;
   //constant v
   cntxt.beginPath(); 
    cntxt.arc(100 + xPosConstantV + (t * vStart), 100, 25, 0 * Math.PI, 2.0 * Math.PI);
    cntxt.fillStyle = "blue";
    cntxt.fill();
    xPosConstantV = 100 + xPosConstantV + (t * vStart);

    //constant a
    cntxt.beginPath(); 
    cntxt.arc(100 + xPosConstantA + (t * vStart) + 0.5 * a * Math.pow(t, 2), 200, 25, 0 * Math.PI, 2.0 * Math.PI);
    cntxt.fillStyle = "blue";
    cntxt.fill();
    xPosConstantA = 100 + xPosConstantA + (t * vStart) + 0.5 * a * Math.pow(t, 2);

};


//cntxt.fillRect(100, 100, 100, 100);



