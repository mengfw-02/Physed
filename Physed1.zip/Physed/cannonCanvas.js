//canvas vs svg?
//learn to do it without react