/* global createCanvas, colorMode, HSB, width, height, random, background, fill, noFill, color, random,
          rect, ellipse, stroke, image, loadImage, frameRate, collideRectRect, collideRectCircle, collidePointCircle,text, 
          mouseX, mouseY, strokeWeight, line, mouseIsPressed, windowWidth, windowHeight, noStroke, 
          keyCode, collideCircleCircle, width, height, keyIsDown, UP_ARROW, triangle, LEFT_ARROW, RIGHT_ARROW, DOWN_ARROW, textSize, noLoop, loop, ESCAPE, loadSound, createButton*/

let x, y, xV, yV, xA, yA, circleWidth;

function setup(){
    createCanvas(800,600);
    circleWidth = 50;
    x = 100;
    y = 500;
    xV = .5;
    xA = 0;
    yV = 0;
    yA = .8;
}

function draw(){
    background(220);
    if (y >= height - (circleWidth / 2) || y <= circleWidth / 2) {
        yV= 0;
    }
    x += xV;
    xV += xA;
    if(yV > 0){
        y -= yV;
    }
    else if(yV == 0){
        y += yV;
    }
   
    yV -= yA;
    
    // Draw balls
    fill(50, 50, 200);
    ellipse(x, y, circleWidth);
}

