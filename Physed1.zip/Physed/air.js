/* global createCanvas, colorMode, HSB, width, height, random, background, fill, noFill, color, random,
          rect, ellipse, stroke, image, loadImage, frameRate, collideRectRect, collideRectCircle, collidePointCircle,text, 
          mouseX, mouseY, strokeWeight, line, mouseIsPressed, windowWidth, windowHeight, noStroke, 
          keyCode, collideCircleCircle, width, height, keyIsDown, UP_ARROW, triangle, LEFT_ARROW, RIGHT_ARROW, DOWN_ARROW, textSize, noLoop, loop, ESCAPE, loadSound, createButton*/

let x1, y1, x1V, y1V, x1A, y1A, circleWidth1;
let x2, y2, x2V, y2V, x2A, y2A, circleWidth2;
let gravity, air, wind;

function setup(){
    createCanvas(800,600);
    circleWidth1 = 50;
    circleWidth2 = 100;

    x1 = 100;
    y1 = 200;
    x1V = 0;
    x1A = 0;
    y1V = 0;
    y1A = 1;

    x2 = 500;
    y2 = 180;
    x2V = 0;
    x2A = 0;
    y2V = 0;
    y2A = 1;

    colorMode (HSB, 360, 100, 100);
    noStroke (0);

    gravity = false;
    air = false;
    wind = false;
   
}
function draw(){
    background(220);
    if(gravity){
        if (y1 >= height - (circleWidth1 / 2) || y1 <= circleWidth1 / 2) {
            y1V= 0;
            gravity = false;
        }
        if (y2 >= height - (circleWidth2 / 2) || y2 <= circleWidth2 / 2) {
            y2V = 0;
        }

        x1 += x1V;
        x1V += x1A;
        y1 += y1V;
        y1V += y1A;

        x2 += x2V;
        x2V += x2A;
        y2 += y2V;
        y2V += y2A;
    }
    if(air){
        if (y1 >= height - (circleWidth1 / 2) || y1 <= circleWidth1 / 2) {
            y1V= 0;
            air = false;
        }
        if (y2 >= height - (circleWidth2 / 2) || y2 <= circleWidth2 / 2) {
            y2V = 0;
        }
    
        x1 += x1V;
        x1V += x1A;
        y1 += y1V;
        y1V += y1A;
    
        x2 += x2V;
        x2V += x2A;
        y2 += y2V;
        y2V += y2A;
    }
    if(wind){
        if (x1 >= width - circleWidth1 / 2 || x1 <= circleWidth1 / 2) {
            x1V = 0;
        }
        if (x2 >= width - circleWidth2 / 2 || x2 <= circleWidth2 / 2) {
            x2V = 0;
        }
        if (y1 >= height - (circleWidth1 / 2) || y1 <= circleWidth1 / 2) {
            y1V= 0;
            wind = false;
        }
        if (y2 >= height - (circleWidth2 / 2) || y2 <= circleWidth2 / 2) {
            y2V = 0;
        }
    
        x1 += x1V;
        x1V += x1A;
        y1 += y1V;
        y1V += y1A;
    
        x2 += x2V;
        x2V += x2A;
        y2 += y2V;
        y2V += y2A;
    }

    // Draw balls
    fill(50, 50, 200);
    ellipse(x1, y1, circleWidth1);
    ellipse(x2, y2, circleWidth2);
    
}

function dropGravity(){
    gravity = true;
    restart();
}

function addAir(){
    air = true;
    restart();
    y1A = .5;
}
function restart(){
    x1 = 100;
    y1 = 200;
    x1V = 0;
    x1A = 0;
    y1V = 0;
    y1A = 1;

    x2 = 500;
    y2 = 180;
    x2V = 0;
    x2A = 0;
    y2V = 0;
    y2A = 1;
}

function addWind(){
    wind = true;
    restart();
    x1A = .5;
    x2A = .5;
    y1A = .5;
}

    